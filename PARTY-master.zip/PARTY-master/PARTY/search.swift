//
//  search.swift
//  PARTY
//
//  Created by Reuben Ukah on 9/2/15.
//  Copyright © 2015 Versuvian. All rights reserved.
//


import UIKit

class search: UITableViewController, UISearchResultsUpdating

{

    
    
    
    
     override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
       self.searchDisplayController!.displaysSearchBarInNavigationBar = true
    
    
    
    }
    
    
}
