//
//  currentlocation.swift
//  PARTY
//
//  Created by Reuben Ukah on 11/13/15.
//  Copyright © 2015 Versuvian. All rights reserved.
//

import UIKit
import Parse


class currentlocation: UITableViewController, CLLocationManagerDelegate {
    
    
    
    
    
}
