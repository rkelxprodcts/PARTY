//
//  ParseHeader.h
//  PARTY
//
//  Created by Reuben Ukah on 9/1/15.
//  Copyright © 2015 Versuvian. All rights reserved.
//

#ifndef ParseHeader_h
#define ParseHeader_h
#import <Parse/Parse.h>
#import <ParseUI/ParseUI.h>
#import "SWRevealViewController.h"
#import "Appirater.h"
#endif /* ParseHeader_h */
